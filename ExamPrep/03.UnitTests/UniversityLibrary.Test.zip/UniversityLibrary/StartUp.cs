﻿using System.Collections.Generic;
using UniversityLibrary;

namespace UniversityLibrary
    {
    public class StartUp
        {
        static void Main(string[] args)
            {
            //UniversityLibraryDataBase db = new UniversityLibraryDataBase();
            //List<TextBook> books = db.GetCatalogue();


            //List<TextBook> books = new List<TextBook>();
            //books.Add(new TextBook("DieHard", "Azis", "Action"));
            //books.Add(new TextBook("IAmNumber4", "Paticus Lore", "Scy-Fi"));
            //books.Add(new TextBook("Harry Potter", "J.K. Rawling", "Fiction"));
            //db.SaveProducts(books);
            }
        }
    }
