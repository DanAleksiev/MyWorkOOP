﻿namespace BorderControl
    {
    public interface IIndentifyable
        {
        public string Name { get; }
       }
    }
