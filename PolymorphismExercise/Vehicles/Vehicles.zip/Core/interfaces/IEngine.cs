﻿namespace Vehicles.Core.interfaces
{
    public interface IEngine
    {
        void Run();
    }
}