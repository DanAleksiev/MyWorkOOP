﻿namespace WildFarm.Core.interfaces
{
    public interface IEngine
    {
        void Run();
    }
}