﻿namespace WildFarm.Models.Interfaces;

public interface IBird : IAnimal
    {
    double WingSize { get; }
    }